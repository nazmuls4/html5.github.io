/* ---------------------------------------------
 common scripts
 --------------------------------------------- */
(function($) {
    'use strict'; // use strict to start

    jQuery(document).ready(function($) {


      

          // testimonial 

         $(".testimonial-list").owlCarousel({			
                items: 4, // Default is 3
                loop: true,
                margin: 30,
                autoplay: true,
                autoplayTimeout: 3000, // Default is 5000
                smartSpeed: 1000, // Default is 250
                dots: true,
                nav: false,
                responsive: {
                    1200: {
                        items: 4
                    },
                    992: {
                        items: 4
                    },
                    768: {
                        items: 3
                    },
                    320: {
                        items: 1
                    },
                    480: {
                        items: 1
                    }
                }
		});


         

    });

	

    jQuery(window).load(function() {
         
           
				
    });




}(jQuery));